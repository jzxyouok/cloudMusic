<template>
  <section class="">tab-header</section>
</template>

<script>
  export default {
    name: 'tab-header',
    data() {
      return {
        title: "切换列表头部",
      }
    },
    created () {

    },
    methods: {},
  }
</script>

<style lang="stylus" rel="stylesheet/stylus">
  @import "~common/stylus/variable"
</style>
